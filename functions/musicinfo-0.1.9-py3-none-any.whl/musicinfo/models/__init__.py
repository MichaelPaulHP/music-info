from .song_types import SongInfo

# Si quieres exponer todas estas funciones cuando alguien importe el módulo tools
__all__ = ['SongInfo' ]
