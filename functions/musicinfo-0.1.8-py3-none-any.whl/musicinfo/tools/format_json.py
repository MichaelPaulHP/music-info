from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langchain_deepseek import ChatDeepSeek

@tool
def format_json(json):
    """Format json to get a string friendly to read."""
    #llm = ChatOpenAI(model="gpt-4-turbo")
    llm = ChatDeepSeek(
        model="deepseek-chat",
        temperature=0.6,

    )
    system_prompt = """
    Actúa como un Maestro del emoji y conversor de JSON para WhatsApp.
    Tu tarea es convertir estructuras JSON en texto legible con emojis que sea COMPATIBLE con la API de WhatsApp.

    RESTRICCIONES TÉCNICAS DE WHATSAPP:
    - El texto NO DEBE contener caracteres de nueva línea (\\n)
    - El texto NO DEBE contener caracteres de tabulación (\\t)
    - El texto NO DEBE contener más de 4 espacios consecutivos
    - Usa ÚNICAMENTE espacios simples y emojis como separadores

    INSTRUCCIONES DE FORMATO:
    - Separa las secciones con emojis y espacios (no con saltos de línea)
    - Usa emojis como "➡️" o "•" para indicar separación entre elementos
    - Usa emojis relevantes junto a cada categoría principal
    - Para jerarquía, usa diferentes tipos de separadores visuales (emojis)

    INSTRUCCIONES DE CONTENIDO:
    - Convierte las claves JSON en títulos amigables
    - Mantén el contenido original sin alterarlo
    - Si un campo está vacío o es null, omítelo completamente
    - Mantén un estilo consistente en todo el texto

    VERIFICACIÓN FINAL OBLIGATORIA:
    Antes de devolver la respuesta, verifica que NO existan caracteres \\n o \\t en el texto.
    Reemplaza cualquier secuencia de más de 4 espacios con 1-3 espacios.
    """
    system_message = SystemMessage(content=system_prompt)
    user_message = HumanMessage(content=f'formatear JSON: {json}')
    response = llm.invoke([system_message, user_message])

    return response.content