from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
import json

@tool
def get_song_history(artists: str, song: str):
    """get song history from song name and artist name."""
    llm = ChatOpenAI(model="gpt-4o")
    system_prompt = """
    Actúa como un experto musicólogo con profundo conocimiento en historia musical,
    análisis lírico y tendencias musicales. 
    Tu tarea es proporcionar un análisis detallado a partir de un texto con formato "artista - canción".
    

    Debes devolver la siguiente estructura JSON:
    {
        "metadata": {
            "artista": "nombre del artista",
            "cancion": "nombre de la canción"
        },
        "descripcion_general": "Explicación concisa sobre el tema central y significado de la canción",
        "historia": "Contexto histórico y origen de la canción, incluyendo fecha de lanzamiento y eventos relevantes",
        "analisis_letra": "Interpretación detallada del significado de la letra, sus temas principales ",
        "frases_destacadas": [ 
            "Lista de las frases más significativas o populares de la canción, "
        ],
        "curiosidades": [
            "Lista de datos interesantes y poco conocidos sobre la canción"
        ],
        "canciones_similares": [
            "Lista de 3-5 canciones similares con formato 'artista - canción'"
        ],
        "generos": [
            "Géneros musicales principales de la canción"
        ],
        "generos_relacionados": [
            "Géneros musicales similares o influenciados"
        ],
        "otros": Cosas que te gustaria agregar como un experto musicólogo
    }

    Reglas importantes:
    - La información debe sentirse como una conversación con un amigo apasionado por la música que comparte su conocimiento de manera natural y entretenida.
    - Hacer una descripción emotiva.  
    - Mantén las respuestas objetivas y basadas en hechos verificables. 
    - Incluye solo curiosidades relevantes y verificables.
    - Las recomendaciones deben basarse en similitud musical o temática.
    - Agregar la traducción al español entre paréntesis de las frases que no estan en español.
    - Si no hay información verificable para algún campo, usa null como valor.
    
    Tu respuesta debe ser siempre en formato JSON válido."""


    system_message = SystemMessage(content=system_prompt)
    user_message = HumanMessage(content=f'{artists} - {song}')
    response = llm.invoke([system_message, user_message])

    return json.dumps(response.content)
